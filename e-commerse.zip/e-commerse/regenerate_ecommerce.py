import os
import pandas as pd
import numpy as np
import pickle
import json
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import LabelEncoder, StandardScaler

# Set up Kaggle
os.environ['KAGGLE_CONFIG_DIR'] = "c:\\Users\\raj18\\Desktop\\ML"

def regenerate():
    print("--- Regenerating E-commerce Model ---")
    data_dir = "c:\\Users\\raj18\\Desktop\\ML\\dataset"
    os.makedirs(data_dir, exist_ok=True)
    
    # Check if dataset exists, if not download
    csv_exists = any(f.endswith('.csv') for f in os.listdir(data_dir)) if os.path.exists(data_dir) else False
    if not csv_exists:
        print("Downloading dataset from Kaggle...")
        os.system(f"kaggle datasets download -d dhairyajeetsingh/ecommerce-customer-behavior-dataset --unzip -p {data_dir}")
    
    # Load data
    csv_file = [f for f in os.listdir(data_dir) if f.endswith('.csv')][0]
    df = pd.read_csv(os.path.join(data_dir, csv_file))
    print(f"Loaded {len(df)} rows.")

    # Drop non-feature columns
    if 'Customer ID' in df.columns:
        df = df.drop('Customer ID', axis=1)
    
    # Target
    target = 'Churned'
    X = df.drop(target, axis=1)
    y = df[target]
    
    # Identify Categorical
    cat_cols = X.select_dtypes(include=['object']).columns.tolist()
    num_cols = X.select_dtypes(exclude=['object']).columns.tolist()
    
    # Encode Categorical
    encoders = {}
    for col in cat_cols:
        le = LabelEncoder()
        X[col] = le.fit_transform(X[col].astype(str))
        encoders[col] = le
        
    # Scale Numerical
    scaler = StandardScaler()
    X[num_cols] = scaler.fit_transform(X[num_cols])
    
    # Minimal training
    print("Training model (this may take a minute)...")
    model = GradientBoostingClassifier(n_estimators=50, random_state=42) # Smaller for speed
    model.fit(X, y)
    
    # Save components
    out_dir = "c:\\Users\\raj18\\Desktop\\ML\\e-commerse"
    os.makedirs(out_dir, exist_ok=True)
    
    with open(os.path.join(out_dir, 'best_model_gradient_boosting.pkl'), 'wb') as f:
        pickle.dump(model, f)
    with open(os.path.join(out_dir, 'scaler.pkl'), 'wb') as f:
        pickle.dump(scaler, f)
    with open(os.path.join(out_dir, 'label_encoders.pkl'), 'wb') as f:
        pickle.dump(encoders, f)
        
    info = {
        "features": X.columns.tolist(),
        "categorical_columns": cat_cols
    }
    with open(os.path.join(out_dir, 'model_info.json'), 'w') as f:
        json.dump(info, f)
        
    print("SUCCESS: Model regenerated and saved to /e-commerse!")

if __name__ == "__main__":
    regenerate()
