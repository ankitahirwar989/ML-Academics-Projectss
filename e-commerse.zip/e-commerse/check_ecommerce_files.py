import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath("c:\\Users\\raj18\\Desktop\\ML\\app.py"))
print(f"DEBUG info:")
print(f"BASE_DIR: {BASE_DIR}")

dir_path = os.path.join(BASE_DIR, 'e-commerse')
print(f"Target dir: {dir_path}")
print(f"Dir exists: {os.path.exists(dir_path)}")

if os.path.exists(dir_path):
    print(f"Files in dir: {os.listdir(dir_path)}")
    
    files = [
        'best_model_gradient_boosting.pkl',
        'scaler.pkl',
        'label_encoders.pkl',
        'model_info.json'
    ]
    
    for f in files:
        f_path = os.path.join(dir_path, f)
        print(f"File {f}: {os.path.exists(f_path)}")
else:
    print(f"Searching for directories in {BASE_DIR}...")
    try:
        print(f"All items: {os.listdir(BASE_DIR)}")
    except Exception as e:
        print(f"Error listing base dir: {e}")
